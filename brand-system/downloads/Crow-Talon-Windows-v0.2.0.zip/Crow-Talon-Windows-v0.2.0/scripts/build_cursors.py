#!/usr/bin/env python3
"""Build and validate the original Crow Talon Windows cursor family.

The artwork is procedural: every cursor is drawn from primitives in this file.
No source image, system icon, font glyph, or third-party cursor is embedded.

The builder writes multi-resolution CUR directories directly so every embedded
PNG is rendered from the same compact 32-pixel nearest-neighbour master.
Artwork occupies a Windows-calibrated portion of each canvas instead of
filling the whole accessibility resource. Animated cursors are RIFF ACON
containers whose frames are independently valid multi-resolution CUR files.
"""

from __future__ import annotations

import ctypes
import hashlib
import io
import json
import math
import os
import struct
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable, Sequence

from PIL import Image, ImageDraw, ImageFont


REPO_ROOT = Path(__file__).resolve().parents[1]
CURSOR_ROOT = REPO_ROOT / "cursors"
SOURCE_DIR = CURSOR_ROOT / "src"
WINDOWS_DIR = CURSOR_ROOT / "windows"
PREVIEW_PATH = CURSOR_ROOT / "preview.png"
PACKAGE_VERSION = "0.2.0"
DOWNLOAD_DIR = REPO_ROOT / "downloads"
PACKAGE_STEM = f"Crow-Talon-Windows-v{PACKAGE_VERSION}"
PACKAGE_PATH = DOWNLOAD_DIR / f"{PACKAGE_STEM}.zip"
PACKAGE_HASH_PATH = DOWNLOAD_DIR / f"{PACKAGE_STEM}.sha256"
PACKAGE_CONTENT_HASHES_PATH = CURSOR_ROOT / "package-files.sha256"
README_PATH = CURSOR_ROOT / "README.md"
LEGACY_LOCAL_PACKAGES = (
    CURSOR_ROOT / f"Crow-Talon-v{PACKAGE_VERSION}.zip",
    CURSOR_ROOT / f"Crow-Talon-v{PACKAGE_VERSION}.sha256",
)
PREVIEW_WIDTH = 1200
PREVIEW_HEIGHT = 640

SIZES = (32, 48, 64, 96)
LOGICAL_SIZE = 32
VISIBLE_ART_SCALE = 0.58
ANI_FRAMES = 12
ANI_JIFFIES = 5  # 5 / 60 second per frame.

# Crow Talon v0.2 is intentionally pixel-built from a tiny opaque palette.
# The approved Crow head informs the feather crown, long beak, black armour,
# cyan edge light, and triangular three-eye signal. No warm hue is used.
VOID = (2, 3, 10, 255)
INK = (5, 7, 15, 255)
NIGHT = (8, 12, 25, 255)
GUNMETAL = (22, 30, 46, 255)
GUNMETAL_2 = (39, 52, 72, 255)
STEEL = (117, 139, 171, 255)
FROST = (230, 246, 255, 255)
DEEP_INDIGO = (40, 38, 112, 255)
ULTRAVIOLET = (111, 76, 255, 255)
ELECTRIC_VIOLET = (151, 113, 255, 255)
ELECTRIC_BLUE = (37, 139, 255, 255)
SIGNAL_CYAN = (57, 224, 255, 255)
PULSE_MAGENTA = (189, 71, 231, 255)
TRANSPARENT = (0, 0, 0, 0)
PALETTE = {
    VOID,
    INK,
    NIGHT,
    GUNMETAL,
    GUNMETAL_2,
    STEEL,
    FROST,
    DEEP_INDIGO,
    ULTRAVIOLET,
    ELECTRIC_VIOLET,
    ELECTRIC_BLUE,
    SIGNAL_CYAN,
    PULSE_MAGENTA,
    TRANSPARENT,
}


@dataclass(frozen=True)
class CursorSpec:
    role: str
    registry_name: str
    hotspot: tuple[int, int]
    draw: Callable[["Canvas", int], None]
    animated: bool = False
    visible_scale: float = VISIBLE_ART_SCALE


class Canvas:
    """A 32-pixel logical surface scaled with nearest-neighbour sampling."""

    def __init__(self, output_size: int):
        self.output_size = output_size
        self.image = Image.new("RGBA", (LOGICAL_SIZE, LOGICAL_SIZE), TRANSPARENT)
        self.draw = ImageDraw.Draw(self.image, "RGBA")

    def n(self, value: float) -> int:
        return max(1, round(value))

    def p(self, point: tuple[float, float]) -> tuple[int, int]:
        return round(point[0]), round(point[1])

    def points(self, values: Sequence[tuple[float, float]]) -> list[tuple[int, int]]:
        return [self.p(value) for value in values]

    def box(self, values: tuple[float, float, float, float]) -> tuple[int, int, int, int]:
        return tuple(round(value) for value in values)  # type: ignore[return-value]

    def polygon(
        self,
        points: Sequence[tuple[float, float]],
        *,
        fill: tuple[int, int, int, int],
        outline: tuple[int, int, int, int] | None = None,
        width: float = 1,
    ) -> None:
        pts = self.points(points)
        self.draw.polygon(pts, fill=fill)
        if outline:
            self.draw.line(pts + [pts[0]], fill=outline, width=self.n(width))

    def line(
        self,
        points: Sequence[tuple[float, float]],
        *,
        fill: tuple[int, int, int, int],
        width: float,
        joint: str = "curve",
    ) -> None:
        self.draw.line(self.points(points), fill=fill, width=self.n(width))

    def ellipse(
        self,
        box: tuple[float, float, float, float],
        *,
        fill: tuple[int, int, int, int] | None = None,
        outline: tuple[int, int, int, int] | None = None,
        width: float = 1,
    ) -> None:
        self.draw.ellipse(self.box(box), fill=fill, outline=outline, width=self.n(width))

    def rectangle(
        self,
        box: tuple[float, float, float, float],
        *,
        fill: tuple[int, int, int, int] | None = None,
        outline: tuple[int, int, int, int] | None = None,
        width: float = 1,
        radius: float = 0,
    ) -> None:
        if radius:
            self.draw.rounded_rectangle(
                self.box(box),
                radius=self.n(radius),
                fill=fill,
                outline=outline,
                width=self.n(width),
            )
        else:
            self.draw.rectangle(
                self.box(box), fill=fill, outline=outline, width=self.n(width)
            )

    def arc(
        self,
        box: tuple[float, float, float, float],
        start: float,
        end: float,
        *,
        fill: tuple[int, int, int, int],
        width: float,
    ) -> None:
        self.draw.arc(self.box(box), start=start, end=end, fill=fill, width=self.n(width))

    def finish(self) -> Image.Image:
        if self.output_size == LOGICAL_SIZE:
            return self.image.copy()
        return self.image.resize(
            (self.output_size, self.output_size), Image.Resampling.NEAREST
        )


def draw_eye(
    canvas: Canvas,
    center: tuple[int, int],
    *,
    forehead: bool = False,
    bright: bool = True,
) -> None:
    """Draw a hard-edged two- or three-pixel Crow signal eye."""
    x, y = center
    if forehead:
        canvas.polygon(
            [(x, y - 2), (x + 2, y), (x, y + 2), (x - 2, y)],
            fill=ULTRAVIOLET,
            outline=INK,
        )
        canvas.rectangle((x, y, x, y), fill=FROST if bright else SIGNAL_CYAN)
    else:
        canvas.rectangle((x - 2, y - 1, x + 2, y + 1), fill=INK)
        canvas.rectangle(
            (x - 1, y, x + 1, y),
            fill=SIGNAL_CYAN if bright else ELECTRIC_BLUE,
        )
        canvas.rectangle((x, y, x, y), fill=FROST)


def draw_three_eyes(
    canvas: Canvas,
    left: tuple[int, int],
    forehead: tuple[int, int],
    right: tuple[int, int],
    *,
    compact: bool = False,
) -> None:
    if compact:
        canvas.rectangle((left[0], left[1], left[0], left[1]), fill=SIGNAL_CYAN)
        canvas.rectangle(
            (forehead[0], forehead[1], forehead[0], forehead[1]),
            fill=ELECTRIC_VIOLET,
        )
        canvas.rectangle((right[0], right[1], right[0], right[1]), fill=SIGNAL_CYAN)
        return
    draw_eye(canvas, left)
    draw_eye(canvas, forehead, forehead=True)
    draw_eye(canvas, right)


def draw_crow_face(canvas: Canvas, center: tuple[int, int], *, compact: bool) -> None:
    """Front-facing Crow mask: feather crown, three eyes, and long steel beak."""
    cx, cy = center
    if compact:
        canvas.polygon(
            [
                (cx - 6, cy - 2),
                (cx - 5, cy - 6),
                (cx - 2, cy - 4),
                (cx, cy - 8),
                (cx + 2, cy - 4),
                (cx + 5, cy - 6),
                (cx + 6, cy - 2),
                (cx + 5, cy + 4),
                (cx + 2, cy + 4),
                (cx, cy + 9),
                (cx - 2, cy + 4),
                (cx - 5, cy + 4),
            ],
            fill=GUNMETAL,
            outline=SIGNAL_CYAN,
        )
        canvas.polygon(
            [(cx - 2, cy), (cx + 2, cy), (cx, cy + 9)],
            fill=STEEL,
            outline=INK,
        )
        draw_three_eyes(
            canvas,
            (cx - 3, cy - 1),
            (cx, cy - 4),
            (cx + 3, cy - 1),
            compact=True,
        )
        return

    canvas.polygon(
        [
            (cx - 8, cy - 2),
            (cx - 7, cy - 8),
            (cx - 4, cy - 6),
            (cx - 2, cy - 11),
            (cx, cy - 7),
            (cx + 2, cy - 11),
            (cx + 4, cy - 6),
            (cx + 7, cy - 8),
            (cx + 8, cy - 2),
            (cx + 6, cy + 5),
            (cx + 2, cy + 6),
            (cx, cy + 13),
            (cx - 2, cy + 6),
            (cx - 6, cy + 5),
        ],
        fill=GUNMETAL,
        outline=SIGNAL_CYAN,
    )
    canvas.polygon(
        [(cx - 3, cy + 1), (cx + 3, cy + 1), (cx, cy + 13)],
        fill=STEEL,
        outline=INK,
    )
    canvas.line([(cx, cy + 2), (cx, cy + 10)], fill=FROST, width=1)
    draw_three_eyes(
        canvas,
        (cx - 4, cy - 1),
        (cx, cy - 5),
        (cx + 4, cy - 1),
    )


def draw_spinner_ring(
    canvas: Canvas,
    center: tuple[int, int],
    radius: int,
    frame: int,
) -> None:
    """Twelve discrete signal blocks; animation never blurs the pixel silhouette."""
    cx, cy = center
    for segment in range(12):
        angle = math.radians(segment * 30 - 90)
        x = round(cx + math.cos(angle) * radius)
        y = round(cy + math.sin(angle) * radius)
        phase = (segment - frame) % 12
        color = (
            FROST
            if phase == 0
            else SIGNAL_CYAN
            if phase == 1
            else ULTRAVIOLET
            if phase in (2, 3)
            else GUNMETAL_2
        )
        canvas.rectangle((x - 1, y - 1, x + 1, y + 1), fill=INK)
        canvas.rectangle((x, y, x, y), fill=color)


def draw_talon_pointer(canvas: Canvas, _frame: int = 0) -> None:
    """Upper-left pointing cybernetic crow foot with three hooked talons."""
    # Rear ankle: a segmented bird leg, not an arrow shaft or human wrist.
    canvas.polygon(
        [(17, 17), (22, 16), (30, 28), (27, 31), (19, 23), (15, 21)],
        fill=INK,
        outline=INK,
        width=2,
    )
    canvas.polygon(
        [(18, 18), (21, 17), (28, 28), (27, 29), (19, 22), (16, 20)],
        fill=GUNMETAL,
        outline=SIGNAL_CYAN,
    )
    canvas.line([(19, 20), (27, 28)], fill=ELECTRIC_VIOLET, width=1)
    canvas.rectangle((22, 23, 25, 26), fill=NIGHT, outline=ULTRAVIOLET)

    # Three separate hooked toes converge on an articulated central palm.
    # The leading talon begins at (1, 1), which is the usable click hotspot.
    talons = (
        [(1, 1), (5, 1), (8, 6), (15, 13), (18, 16), (14, 18), (10, 13), (5, 7)],
        [(10, 1), (14, 1), (12, 6), (15, 12), (18, 16), (14, 17), (10, 9)],
        [(1, 10), (1, 14), (6, 13), (11, 15), (18, 17), (16, 21), (9, 18), (4, 16)],
    )
    for talon in talons:
        canvas.polygon(talon, fill=GUNMETAL, outline=SIGNAL_CYAN)

    # Hard black claw tips and visible mechanical joints sell the silhouette.
    canvas.polygon([(1, 1), (5, 1), (3, 4)], fill=FROST, outline=INK)
    canvas.polygon([(10, 1), (14, 1), (11, 5)], fill=FROST, outline=INK)
    canvas.polygon([(2, 10), (1, 14), (5, 12)], fill=FROST, outline=INK)
    for x, y in ((7, 7), (12, 9), (8, 15)):
        canvas.ellipse((x - 2, y - 2, x + 2, y + 2), fill=INK)
        canvas.rectangle((x - 1, y - 1, x + 1, y + 1), fill=ULTRAVIOLET)
        canvas.rectangle((x, y, x, y), fill=SIGNAL_CYAN)

    canvas.polygon(
        [(12, 14), (17, 12), (23, 16), (23, 21), (17, 24), (12, 20)],
        fill=INK,
        outline=INK,
        width=2,
    )
    canvas.polygon(
        [(13, 15), (17, 13), (22, 16), (22, 20), (17, 22), (13, 20)],
        fill=NIGHT,
        outline=ELECTRIC_VIOLET,
    )
    canvas.ellipse((16, 16, 20, 20), fill=ULTRAVIOLET, outline=SIGNAL_CYAN)
    canvas.rectangle((18, 18, 18, 18), fill=FROST)


def draw_help(canvas: Canvas, frame: int = 0) -> None:
    draw_talon_pointer(canvas, frame)
    canvas.rectangle((21, 1, 31, 12), fill=INK)
    canvas.rectangle((22, 2, 30, 11), fill=NIGHT, outline=ULTRAVIOLET)
    canvas.line([(24, 5), (25, 3), (28, 3), (29, 4), (29, 6), (27, 7), (27, 8)], fill=SIGNAL_CYAN, width=1)
    canvas.rectangle((27, 10, 27, 10), fill=FROST)


def draw_working(canvas: Canvas, frame: int = 0) -> None:
    draw_talon_pointer(canvas, frame)
    canvas.rectangle((17, 17, 31, 31), fill=INK)
    canvas.rectangle((18, 18, 30, 30), fill=NIGHT, outline=DEEP_INDIGO)
    draw_spinner_ring(canvas, (24, 24), 5, frame)
    canvas.polygon([(22, 21), (27, 24), (22, 27)], fill=FROST, outline=ELECTRIC_BLUE)


def draw_busy(canvas: Canvas, frame: int = 0) -> None:
    draw_spinner_ring(canvas, (16, 16), 13, frame)
    draw_crow_face(canvas, (16, 16), compact=True)


def draw_precision(canvas: Canvas, _frame: int = 0) -> None:
    canvas.line([(16, 1), (16, 11)], fill=INK, width=3)
    canvas.line([(16, 21), (16, 30)], fill=INK, width=3)
    canvas.line([(1, 16), (11, 16)], fill=INK, width=3)
    canvas.line([(21, 16), (30, 16)], fill=INK, width=3)
    canvas.line([(16, 1), (16, 11)], fill=SIGNAL_CYAN, width=1)
    canvas.line([(16, 21), (16, 30)], fill=SIGNAL_CYAN, width=1)
    canvas.line([(1, 16), (11, 16)], fill=SIGNAL_CYAN, width=1)
    canvas.line([(21, 16), (30, 16)], fill=SIGNAL_CYAN, width=1)
    canvas.rectangle((11, 11, 21, 21), fill=INK)
    canvas.rectangle((12, 12, 20, 20), fill=NIGHT, outline=ULTRAVIOLET)
    draw_three_eyes(canvas, (14, 17), (16, 14), (18, 17), compact=True)
    canvas.rectangle((16, 16, 16, 16), fill=FROST)


def draw_text(canvas: Canvas, _frame: int = 0) -> None:
    """Narrow high-contrast I-beam calibrated to the Windows text cursor."""
    canvas.line([(11, 2), (21, 2)], fill=INK, width=3)
    canvas.line([(12, 2), (20, 2)], fill=ELECTRIC_VIOLET, width=1)
    canvas.line([(16, 2), (16, 30)], fill=INK, width=3)
    canvas.line([(16, 3), (16, 29)], fill=SIGNAL_CYAN, width=1)
    canvas.line([(11, 30), (21, 30)], fill=INK, width=3)
    canvas.line([(12, 30), (20, 30)], fill=ELECTRIC_VIOLET, width=1)
    canvas.rectangle((15, 15, 17, 17), fill=INK)
    canvas.rectangle((16, 16, 16, 16), fill=FROST)


def draw_handwriting(canvas: Canvas, _frame: int = 0) -> None:
    """Stepped black feather with a cyan edge and a precise steel nib."""
    canvas.polygon(
        [(3, 29), (6, 19), (11, 9), (27, 2), (23, 17), (12, 25)],
        fill=INK,
        outline=INK,
        width=2,
    )
    canvas.polygon(
        [(4, 28), (7, 18), (12, 9), (27, 2), (22, 16), (11, 24)],
        fill=GUNMETAL,
        outline=SIGNAL_CYAN,
    )
    canvas.polygon(
        [(7, 23), (8, 18), (25, 4), (18, 18)],
        fill=NIGHT,
        outline=ELECTRIC_VIOLET,
    )
    canvas.line([(4, 28), (22, 9)], fill=FROST, width=1)
    canvas.line([(10, 17), (6, 16)], fill=ELECTRIC_BLUE, width=1)
    canvas.line([(14, 13), (11, 10)], fill=ULTRAVIOLET, width=1)
    draw_three_eyes(canvas, (18, 10), (21, 7), (23, 10), compact=True)
    canvas.polygon([(3, 29), (5, 25), (8, 28)], fill=STEEL, outline=INK)


def draw_unavailable(canvas: Canvas, _frame: int = 0) -> None:
    ring = [(9, 2), (23, 2), (30, 9), (30, 23), (23, 30), (9, 30), (2, 23), (2, 9)]
    inner = [(10, 5), (22, 5), (27, 10), (27, 22), (22, 27), (10, 27), (5, 22), (5, 10)]
    canvas.polygon(ring, fill=INK, outline=INK, width=2)
    canvas.polygon(inner, fill=NIGHT, outline=ULTRAVIOLET, width=2)
    draw_crow_face(canvas, (16, 16), compact=True)
    canvas.line([(6, 6), (26, 26)], fill=INK, width=5)
    canvas.line([(6, 6), (26, 26)], fill=PULSE_MAGENTA, width=2)


def arrow_head(
    canvas: Canvas,
    tip: tuple[float, float],
    direction: tuple[float, float],
    *,
    color: tuple[int, int, int, int] = SIGNAL_CYAN,
    length: float = 5,
    spread: float = 3,
) -> None:
    dx, dy = direction
    norm = math.hypot(dx, dy)
    dx, dy = dx / norm, dy / norm
    px, py = -dy, dx
    base_x, base_y = tip[0] - dx * length, tip[1] - dy * length
    canvas.polygon(
        [
            tip,
            (base_x + px * spread, base_y + py * spread),
            (base_x - px * spread, base_y - py * spread),
        ],
        fill=GUNMETAL,
        outline=color,
    )
    canvas.line(
        [
            tip,
            (base_x + px * spread, base_y + py * spread),
        ],
        fill=FROST,
        width=1,
    )


def draw_resize_axis(
    canvas: Canvas,
    direction: tuple[float, float],
    _frame: int = 0,
) -> None:
    dx, dy = direction
    norm = math.hypot(dx, dy)
    dx, dy = dx / norm, dy / norm
    a = (16 - dx * 13, 16 - dy * 13)
    b = (16 + dx * 13, 16 + dy * 13)
    canvas.line([a, b], fill=INK, width=5)
    canvas.line([a, b], fill=ELECTRIC_VIOLET, width=2)
    arrow_head(canvas, a, (-dx, -dy), color=SIGNAL_CYAN)
    arrow_head(canvas, b, (dx, dy), color=SIGNAL_CYAN)
    canvas.rectangle((12, 12, 20, 20), fill=INK)
    canvas.rectangle((13, 13, 19, 19), fill=NIGHT, outline=ULTRAVIOLET)
    draw_three_eyes(canvas, (14, 17), (16, 14), (18, 17), compact=True)


def draw_resize_v(canvas: Canvas, frame: int = 0) -> None:
    draw_resize_axis(canvas, (0, 1), frame)


def draw_resize_h(canvas: Canvas, frame: int = 0) -> None:
    draw_resize_axis(canvas, (1, 0), frame)


def draw_resize_d1(canvas: Canvas, frame: int = 0) -> None:
    draw_resize_axis(canvas, (1, 1), frame)


def draw_resize_d2(canvas: Canvas, frame: int = 0) -> None:
    draw_resize_axis(canvas, (1, -1), frame)


def draw_move(canvas: Canvas, _frame: int = 0) -> None:
    for direction in ((0, -1), (1, 0), (0, 1), (-1, 0)):
        dx, dy = direction
        start = (16 + dx * 3, 16 + dy * 3)
        tip = (16 + dx * 14, 16 + dy * 14)
        canvas.line([start, tip], fill=INK, width=5)
        canvas.line([start, tip], fill=ELECTRIC_VIOLET, width=2)
        arrow_head(canvas, tip, direction, color=SIGNAL_CYAN, length=5, spread=3)
    canvas.rectangle((12, 12, 20, 20), fill=INK)
    canvas.rectangle((13, 13, 19, 19), fill=NIGHT, outline=ULTRAVIOLET)
    draw_three_eyes(canvas, (14, 17), (16, 14), (18, 17), compact=True)


def draw_alternate(canvas: Canvas, _frame: int = 0) -> None:
    """Narrow up-select arrow with a restrained frontal Crow signal."""
    canvas.polygon(
        [(16, 1), (24, 12), (19, 11), (19, 30), (13, 30), (13, 11), (8, 12)],
        fill=INK,
        outline=INK,
        width=2,
    )
    canvas.polygon(
        [(16, 2), (22, 11), (18, 10), (18, 28), (14, 28), (14, 10), (10, 11)],
        fill=GUNMETAL,
        outline=SIGNAL_CYAN,
    )
    canvas.polygon(
        [(16, 3), (19, 10), (17, 9), (16, 17), (15, 9), (13, 10)],
        fill=NIGHT,
        outline=ELECTRIC_VIOLET,
    )
    draw_three_eyes(canvas, (14, 10), (16, 7), (18, 10), compact=True)
    canvas.line([(16, 14), (16, 26)], fill=FROST, width=1)


def draw_link(canvas: Canvas, _frame: int = 0) -> None:
    """Cybernetic crow claw closing around a link node."""
    # Pointing talon keeps the familiar link-cursor action at the hotspot.
    canvas.polygon(
        [(8, 2), (12, 2), (12, 16), (10, 20), (7, 18), (8, 13)],
        fill=INK,
        outline=INK,
        width=2,
    )
    canvas.polygon(
        [(9, 3), (11, 3), (11, 15), (9, 18), (8, 17), (9, 13)],
        fill=GUNMETAL,
        outline=SIGNAL_CYAN,
    )
    canvas.polygon([(8, 2), (12, 2), (10, 5)], fill=FROST, outline=INK)

    # Two hooked side talons curl around the violet link node.
    canvas.polygon(
        [(12, 15), (18, 10), (23, 11), (25, 14), (22, 14), (20, 13), (15, 18)],
        fill=GUNMETAL,
        outline=SIGNAL_CYAN,
    )
    canvas.polygon(
        [(14, 18), (23, 17), (27, 20), (27, 24), (24, 23), (23, 21), (15, 22)],
        fill=GUNMETAL,
        outline=SIGNAL_CYAN,
    )
    canvas.ellipse((12, 15, 20, 23), fill=INK, outline=ELECTRIC_VIOLET)
    canvas.ellipse((14, 17, 18, 21), fill=ULTRAVIOLET, outline=SIGNAL_CYAN)
    canvas.rectangle((16, 19, 16, 19), fill=FROST)

    # Short articulated ankle and three exposed joint nodes.
    canvas.polygon(
        [(13, 21), (22, 21), (26, 28), (23, 30), (17, 25), (11, 25)],
        fill=INK,
        outline=INK,
        width=2,
    )
    canvas.polygon(
        [(14, 22), (21, 22), (24, 28), (23, 29), (17, 24), (12, 24)],
        fill=NIGHT,
        outline=ULTRAVIOLET,
    )
    for x, y in ((10, 13), (21, 12), (24, 20)):
        canvas.rectangle((x - 1, y - 1, x + 1, y + 1), fill=INK)
        canvas.rectangle((x, y, x, y), fill=ELECTRIC_BLUE)


SPECS: tuple[CursorSpec, ...] = (
    CursorSpec("normal", "Arrow", (1, 1), draw_talon_pointer, visible_scale=0.56),
    CursorSpec("help", "Help", (1, 1), draw_help, visible_scale=0.60),
    CursorSpec(
        "working",
        "AppStarting",
        (1, 1),
        draw_working,
        animated=True,
        visible_scale=0.75,
    ),
    CursorSpec(
        "busy",
        "Wait",
        (16, 16),
        draw_busy,
        animated=True,
        visible_scale=0.70,
    ),
    CursorSpec("precision", "Crosshair", (16, 16), draw_precision, visible_scale=0.67),
    CursorSpec("text", "IBeam", (16, 16), draw_text, visible_scale=0.68),
    CursorSpec("handwriting", "NWPen", (3, 29), draw_handwriting, visible_scale=0.70),
    CursorSpec("unavailable", "No", (16, 16), draw_unavailable, visible_scale=0.53),
    CursorSpec("resize-v", "SizeNS", (16, 16), draw_resize_v, visible_scale=0.86),
    CursorSpec("resize-h", "SizeWE", (16, 16), draw_resize_h, visible_scale=0.86),
    CursorSpec("resize-d1", "SizeNWSE", (16, 16), draw_resize_d1, visible_scale=0.85),
    CursorSpec("resize-d2", "SizeNESW", (16, 16), draw_resize_d2, visible_scale=0.85),
    CursorSpec("move", "SizeAll", (16, 16), draw_move, visible_scale=0.81),
    CursorSpec("alternate", "UpArrow", (16, 1), draw_alternate, visible_scale=0.62),
    CursorSpec("link", "Hand", (10, 2), draw_link, visible_scale=0.75),
)


def compact_logical_art(spec: CursorSpec, image: Image.Image) -> Image.Image:
    """Scale visible artwork around its hotspot while retaining a 32px canvas."""
    target = max(1, round(LOGICAL_SIZE * spec.visible_scale))
    compact = image.resize((target, target), Image.Resampling.NEAREST)
    source_hot_x, source_hot_y = spec.hotspot
    compact_hot_x = round(source_hot_x * spec.visible_scale)
    compact_hot_y = round(source_hot_y * spec.visible_scale)
    offset_x = source_hot_x - compact_hot_x
    offset_y = source_hot_y - compact_hot_y
    logical = Image.new("RGBA", (LOGICAL_SIZE, LOGICAL_SIZE), TRANSPARENT)
    logical.alpha_composite(compact, (offset_x, offset_y))

    # Resampling must never make the active click point transparent.
    source_hot_pixel = image.getpixel(spec.hotspot)
    if source_hot_pixel[3] == 0:
        raise ValueError(f"{spec.role}: raw artwork does not cover its hotspot")
    logical.putpixel(spec.hotspot, source_hot_pixel)
    return logical


def render(spec: CursorSpec, size: int, frame: int = 0) -> Image.Image:
    canvas = Canvas(LOGICAL_SIZE)
    spec.draw(canvas, frame)
    logical = compact_logical_art(spec, canvas.finish())
    if size == LOGICAL_SIZE:
        return logical
    return logical.resize((size, size), Image.Resampling.NEAREST)


def hotspot_for_size(spec: CursorSpec, size: int) -> tuple[int, int]:
    x = min(size - 1, max(0, round(spec.hotspot[0] * size / LOGICAL_SIZE)))
    y = min(size - 1, max(0, round(spec.hotspot[1] * size / LOGICAL_SIZE)))
    return x, y


def build_cur_bytes(spec: CursorSpec, frame: int = 0) -> bytes:
    payloads: list[tuple[int, bytes]] = []
    for size in SIZES:
        buffer = io.BytesIO()
        render(spec, size, frame).save(buffer, format="PNG", optimize=True)
        payloads.append((size, buffer.getvalue()))

    header_size = 6 + 16 * len(payloads)
    payload_offset = header_size
    entries: list[bytes] = []
    body: list[bytes] = []
    for size, payload in payloads:
        hot_x, hot_y = hotspot_for_size(spec, size)
        entries.append(
            struct.pack(
                "<BBBBHHII",
                0 if size == 256 else size,
                0 if size == 256 else size,
                0,
                0,
                hot_x,
                hot_y,
                len(payload),
                payload_offset,
            )
        )
        body.append(payload)
        payload_offset += len(payload)
    return struct.pack("<HHH", 0, 2, len(payloads)) + b"".join(entries + body)


def riff_chunk(tag: bytes, payload: bytes) -> bytes:
    if len(tag) != 4:
        raise ValueError("RIFF tags must be four bytes")
    pad = b"\0" if len(payload) & 1 else b""
    return tag + struct.pack("<I", len(payload)) + payload + pad


def build_ani_bytes(spec: CursorSpec) -> bytes:
    frames = [build_cur_bytes(spec, frame) for frame in range(ANI_FRAMES)]
    anih = struct.pack(
        "<9I",
        36,  # cbSizeOf
        ANI_FRAMES,
        ANI_FRAMES,
        0,
        0,
        0,
        0,
        ANI_JIFFIES,
        0x00000003,  # AF_ICON | AF_SEQUENCE
    )
    rates = struct.pack(f"<{ANI_FRAMES}I", *([ANI_JIFFIES] * ANI_FRAMES))
    sequence = struct.pack(f"<{ANI_FRAMES}I", *range(ANI_FRAMES))
    frame_list = b"fram" + b"".join(riff_chunk(b"icon", frame) for frame in frames)
    info = b"INFO" + riff_chunk(b"INAM", f"Crow Talon {spec.role}\0".encode("ascii"))
    body = (
        b"ACON"
        + riff_chunk(b"anih", anih)
        + riff_chunk(b"rate", rates)
        + riff_chunk(b"seq ", sequence)
        + riff_chunk(b"LIST", frame_list)
        + riff_chunk(b"LIST", info)
    )
    return b"RIFF" + struct.pack("<I", len(body)) + body


def parse_cur(data: bytes, *, label: str) -> list[dict[str, int]]:
    if len(data) < 6:
        raise ValueError(f"{label}: CUR file is truncated")
    reserved, kind, count = struct.unpack_from("<HHH", data, 0)
    if (reserved, kind, count) != (0, 2, len(SIZES)):
        raise ValueError(
            f"{label}: expected CUR header (0, 2, {len(SIZES)}), "
            f"got {(reserved, kind, count)}"
        )
    entries: list[dict[str, int]] = []
    seen_sizes: set[int] = set()
    for index in range(count):
        entry_offset = 6 + index * 16
        if entry_offset + 16 > len(data):
            raise ValueError(f"{label}: CUR directory is truncated")
        width_byte, height_byte, colors, reserved_byte, hot_x, hot_y, length, offset = (
            struct.unpack_from("<BBBBHHII", data, entry_offset)
        )
        width = 256 if width_byte == 0 else width_byte
        height = 256 if height_byte == 0 else height_byte
        if colors != 0 or reserved_byte != 0:
            raise ValueError(f"{label}: invalid CUR directory flags")
        if width != height or width not in SIZES:
            raise ValueError(f"{label}: unexpected image size {width}x{height}")
        if not (0 <= hot_x < width and 0 <= hot_y < height):
            raise ValueError(f"{label}: hotspot {hot_x},{hot_y} outside {width}x{height}")
        if offset < 6 + count * 16 or offset + length > len(data):
            raise ValueError(f"{label}: image payload points outside the file")
        payload = data[offset : offset + length]
        if not payload.startswith(b"\x89PNG\r\n\x1a\n"):
            raise ValueError(f"{label}: {width}px entry is not PNG-compressed")
        seen_sizes.add(width)
        entries.append(
            {
                "size": width,
                "hotspot_x": hot_x,
                "hotspot_y": hot_y,
                "bytes": length,
            }
        )
    if seen_sizes != set(SIZES):
        raise ValueError(f"{label}: missing sizes; found {sorted(seen_sizes)}")
    return sorted(entries, key=lambda entry: entry["size"])


def iter_riff_chunks(data: bytes, start: int, end: int) -> Iterable[tuple[bytes, bytes]]:
    cursor = start
    while cursor < end:
        if cursor + 8 > end:
            raise ValueError("truncated RIFF chunk header")
        tag = data[cursor : cursor + 4]
        length = struct.unpack_from("<I", data, cursor + 4)[0]
        payload_start = cursor + 8
        payload_end = payload_start + length
        if payload_end > end:
            raise ValueError(f"RIFF chunk {tag!r} extends past container")
        yield tag, data[payload_start:payload_end]
        cursor = payload_end + (length & 1)
    if cursor != end:
        raise ValueError("RIFF chunk alignment error")


def validate_ani(data: bytes, *, label: str) -> dict[str, int]:
    if len(data) < 12 or data[:4] != b"RIFF" or data[8:12] != b"ACON":
        raise ValueError(f"{label}: not a RIFF ACON file")
    declared = struct.unpack_from("<I", data, 4)[0]
    if declared + 8 != len(data):
        raise ValueError(f"{label}: RIFF size mismatch")
    anih_payload = None
    rates = None
    sequence = None
    frame_payloads: list[bytes] = []
    for tag, payload in iter_riff_chunks(data, 12, len(data)):
        if tag == b"anih":
            anih_payload = payload
        elif tag == b"rate":
            rates = payload
        elif tag == b"seq ":
            sequence = payload
        elif tag == b"LIST" and payload[:4] == b"fram":
            frame_payloads.extend(
                child_payload
                for child_tag, child_payload in iter_riff_chunks(
                    payload, 4, len(payload)
                )
                if child_tag == b"icon"
            )
    if anih_payload is None or len(anih_payload) != 36:
        raise ValueError(f"{label}: missing or invalid anih chunk")
    (
        header_size,
        frame_count,
        step_count,
        _width,
        _height,
        _bit_count,
        _planes,
        jiffies,
        flags,
    ) = struct.unpack("<9I", anih_payload)
    if header_size != 36 or frame_count != ANI_FRAMES or step_count != ANI_FRAMES:
        raise ValueError(f"{label}: invalid ANI frame metadata")
    if jiffies != ANI_JIFFIES or flags != 3:
        raise ValueError(f"{label}: invalid ANI timing or flags")
    if rates is None or len(rates) != ANI_FRAMES * 4:
        raise ValueError(f"{label}: invalid rate chunk")
    if sequence is None or len(sequence) != ANI_FRAMES * 4:
        raise ValueError(f"{label}: invalid sequence chunk")
    if list(struct.unpack(f"<{ANI_FRAMES}I", sequence)) != list(range(ANI_FRAMES)):
        raise ValueError(f"{label}: ANI sequence is not deterministic")
    if len(frame_payloads) != ANI_FRAMES:
        raise ValueError(
            f"{label}: expected {ANI_FRAMES} icon frames, got {len(frame_payloads)}"
        )
    for index, frame_data in enumerate(frame_payloads):
        parse_cur(frame_data, label=f"{label} frame {index}")
    return {"frames": frame_count, "steps": step_count, "jiffies": jiffies}


def load_cursor_from_file(path: Path) -> None:
    if os.name != "nt":
        return
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    load = user32.LoadCursorFromFileW
    load.argtypes = [ctypes.c_wchar_p]
    load.restype = ctypes.c_void_p
    destroy = user32.DestroyCursor
    destroy.argtypes = [ctypes.c_void_p]
    destroy.restype = ctypes.c_bool
    ctypes.set_last_error(0)
    handle = load(str(path))
    if not handle:
        error = ctypes.get_last_error()
        raise OSError(error, f"LoadCursorFromFileW rejected {path.name}")
    destroy(handle)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def validate_pixel_source(spec: CursorSpec, image: Image.Image) -> dict[str, object]:
    if image.size != (LOGICAL_SIZE, LOGICAL_SIZE):
        raise ValueError(f"{spec.role}: source grid is not {LOGICAL_SIZE}px")
    raw_pixels = image.tobytes()
    pixels = [
        tuple(raw_pixels[offset : offset + 4])
        for offset in range(0, len(raw_pixels), 4)
    ]
    colors = set(pixels)
    unexpected = colors - PALETTE
    if unexpected:
        raise ValueError(
            f"{spec.role}: source contains colours outside the Crow pixel palette: "
            f"{sorted(unexpected)}"
        )
    alpha_values = {color[3] for color in colors}
    if not alpha_values <= {0, 255}:
        raise ValueError(f"{spec.role}: source uses softened alpha values")
    bounds = image.getbbox()
    if bounds is None:
        raise ValueError(f"{spec.role}: source is empty")
    opaque_pixels = sum(1 for pixel in pixels if pixel[3] == 255)
    if opaque_pixels < 24:
        raise ValueError(f"{spec.role}: source silhouette is too sparse")
    hot_x, hot_y = spec.hotspot
    if image.getpixel((hot_x, hot_y))[3] != 255:
        raise ValueError(
            f"{spec.role}: logical hotspot {spec.hotspot} is not on an opaque pixel"
        )
    return {
        "grid": [LOGICAL_SIZE, LOGICAL_SIZE],
        "alpha": "1-bit",
        "palette_colours_used": len(colors - {TRANSPARENT}),
        "opaque_pixels": opaque_pixels,
        "bounds": list(bounds),
        "hotspot_is_opaque": True,
    }


def write_preview(specs: Sequence[CursorSpec]) -> None:
    columns, rows = 5, 3
    cell_w, cell_h = 232, 170
    preview = Image.new("RGBA", (PREVIEW_WIDTH, PREVIEW_HEIGHT), VOID)
    draw = ImageDraw.Draw(preview, "RGBA")
    try:
        title_font = ImageFont.load_default(size=24)
        font = ImageFont.load_default(size=17)
        small_font = ImageFont.load_default(size=12)
    except TypeError:
        title_font = ImageFont.load_default()
        font = ImageFont.load_default()
        small_font = font

    for x in range(0, PREVIEW_WIDTH, 16):
        draw.line((x, 0, x, PREVIEW_HEIGHT), fill=(40, 38, 112, 42), width=1)
    for y in range(0, PREVIEW_HEIGHT, 16):
        draw.line((0, y, PREVIEW_WIDTH, y), fill=(40, 38, 112, 42), width=1)
    draw.text((24, 18), "CROW TALON v0.2", font=title_font, fill=FROST)
    draw.text(
        (24, 48),
        "COMPACT CYBER-CLAW SYSTEM  //  NORMAL WINDOWS SCALE  //  32 · 48 · 64 · 96",
        font=small_font,
        fill=SIGNAL_CYAN,
    )

    for index, spec in enumerate(specs):
        column, row = index % columns, index // columns
        x0, y0 = 20 + column * cell_w, 78 + row * cell_h
        draw.rectangle(
            (x0 + 4, y0 + 4, x0 + cell_w - 8, y0 + cell_h - 8),
            fill=NIGHT,
            outline=DEEP_INDIGO,
            width=2,
        )
        frame = 2 if spec.animated else 0
        art = render(spec, 96, frame)
        preview.alpha_composite(art, (x0 + (cell_w - 96) // 2, y0 + 12))
        label = spec.role.replace("-", " ").upper()
        box = draw.textbbox((0, 0), label, font=font)
        text_w = box[2] - box[0]
        draw.text(
            (x0 + (cell_w - text_w) / 2, y0 + 116),
            label,
            font=font,
            fill=FROST,
        )
        registry = spec.registry_name.upper()
        registry_box = draw.textbbox((0, 0), registry, font=small_font)
        registry_w = registry_box[2] - registry_box[0]
        draw.text(
            (x0 + (cell_w - registry_w) / 2, y0 + 143),
            registry,
            font=small_font,
            fill=ELECTRIC_VIOLET,
        )
    preview.convert("RGB").save(PREVIEW_PATH, "PNG", optimize=True)


def install_ps1() -> str:
    return r"""# Crow Talon v0.2 per-user cursor scheme installer.
# Running this script registers the scheme. It only activates it with -Activate.
[CmdletBinding(SupportsShouldProcess)]
param([switch]$Activate)

$ErrorActionPreference = 'Stop'
$schemeName = 'Crow Talon'
$packageVersion = '0.2.0'
$source = Join-Path $PSScriptRoot 'windows'
$destination = Join-Path $env:LOCALAPPDATA 'Crow\Cursors\Crow-Talon'
$schemesKey = 'HKCU:\Control Panel\Cursors\Schemes'
$cursorsKey = 'HKCU:\Control Panel\Cursors'

$roles = [ordered]@{
    Arrow       = 'normal.cur'
    Help        = 'help.cur'
    AppStarting = 'working.ani'
    Wait        = 'busy.ani'
    Crosshair   = 'precision.cur'
    IBeam       = 'text.cur'
    NWPen       = 'handwriting.cur'
    No          = 'unavailable.cur'
    SizeNS      = 'resize-v.cur'
    SizeWE      = 'resize-h.cur'
    SizeNWSE    = 'resize-d1.cur'
    SizeNESW    = 'resize-d2.cur'
    SizeAll     = 'move.cur'
    UpArrow     = 'alternate.cur'
    Hand        = 'link.cur'
}
$registered = $false

foreach ($file in $roles.Values) {
    $candidate = Join-Path $source $file
    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
        throw "Incomplete Crow Talon v$packageVersion package. Extract the entire ZIP before running install.ps1. Missing: $candidate"
    }
}

if ($PSCmdlet.ShouldProcess($destination, 'Install Crow Talon cursor files')) {
    New-Item -ItemType Directory -Path $destination -Force | Out-Null
    foreach ($file in $roles.Values) {
        Copy-Item -LiteralPath (Join-Path $source $file) -Destination $destination -Force
    }
    # Keep static fallbacks available even though the scheme prefers ANI.
    Copy-Item -LiteralPath (Join-Path $source 'working.cur') -Destination $destination -Force
    Copy-Item -LiteralPath (Join-Path $source 'busy.cur') -Destination $destination -Force

    New-Item -Path $schemesKey -Force | Out-Null
    $schemePaths = foreach ($file in $roles.Values) { Join-Path $destination $file }
    New-ItemProperty -Path $schemesKey -Name $schemeName -Value ($schemePaths -join ',') `
        -PropertyType String -Force | Out-Null
    $registered = $true
}

if ($Activate -and $PSCmdlet.ShouldProcess($schemeName, 'Activate cursor scheme')) {
    New-Item -Path $cursorsKey -Force | Out-Null
    foreach ($entry in $roles.GetEnumerator()) {
        Set-ItemProperty -Path $cursorsKey -Name $entry.Key `
            -Value (Join-Path $destination $entry.Value)
    }
    Set-Item -Path $cursorsKey -Value $schemeName

    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class CrowCursorRefresh {
    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool SystemParametersInfo(
        uint uiAction, uint uiParam, IntPtr pvParam, uint fWinIni);
}
'@
    if (-not [CrowCursorRefresh]::SystemParametersInfo(0x0057, 0, [IntPtr]::Zero, 3)) {
        throw "The scheme was registered, but Windows could not reload cursors."
    }
}

if ($registered) {
    Write-Host "Crow Talon v$packageVersion is registered for this Windows account."
} else {
    Write-Host "Crow Talon v$packageVersion registration was not performed."
}
if ($registered -and -not $Activate) {
    Write-Host "Select it in Mouse Properties > Pointers, or rerun with -Activate."
}
"""


def uninstall_ps1() -> str:
    return r"""# Crow Talon v0.2 per-user cursor scheme uninstaller.
[CmdletBinding(SupportsShouldProcess)]
param()

$ErrorActionPreference = 'Stop'
$schemeName = 'Crow Talon'
$destination = Join-Path $env:LOCALAPPDATA 'Crow\Cursors\Crow-Talon'
$schemesKey = 'HKCU:\Control Panel\Cursors\Schemes'
$cursorsKey = 'HKCU:\Control Panel\Cursors'
$registryRoles = @(
    'Arrow','Help','AppStarting','Wait','Crosshair','IBeam','NWPen','No',
    'SizeNS','SizeWE','SizeNWSE','SizeNESW','SizeAll','UpArrow','Hand'
)
$removed = $false

if ($PSCmdlet.ShouldProcess($schemeName, 'Unregister cursor scheme')) {
    Remove-ItemProperty -Path $schemesKey -Name $schemeName -ErrorAction SilentlyContinue

    $wasActive = $false
    foreach ($role in $registryRoles) {
        $current = (Get-ItemProperty -Path $cursorsKey -Name $role `
            -ErrorAction SilentlyContinue).$role
        if ($current -and $current.StartsWith($destination, [StringComparison]::OrdinalIgnoreCase)) {
            Set-ItemProperty -Path $cursorsKey -Name $role -Value ''
            $wasActive = $true
        }
    }
    if ($wasActive) {
        Set-Item -Path $cursorsKey -Value ''
        Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class CrowCursorRefresh {
    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool SystemParametersInfo(
        uint uiAction, uint uiParam, IntPtr pvParam, uint fWinIni);
}
'@
        [void][CrowCursorRefresh]::SystemParametersInfo(0x0057, 0, [IntPtr]::Zero, 3)
    }

    $safeRoot = Join-Path $env:LOCALAPPDATA 'Crow\Cursors'
    if ((Test-Path -LiteralPath $destination) -and
        $destination.StartsWith($safeRoot, [StringComparison]::OrdinalIgnoreCase)) {
        Remove-Item -LiteralPath $destination -Recurse -Force
    }
    $removed = $true
}

if ($removed) {
    Write-Host 'Crow Talon has been removed from this Windows account.'
} else {
    Write-Host 'Crow Talon removal was not performed.'
}
"""


def cursor_inf() -> str:
    files = [
        "normal.cur",
        "help.cur",
        "working.ani",
        "working.cur",
        "busy.ani",
        "busy.cur",
        "precision.cur",
        "text.cur",
        "handwriting.cur",
        "unavailable.cur",
        "resize-v.cur",
        "resize-h.cur",
        "resize-d1.cur",
        "resize-d2.cur",
        "move.cur",
        "alternate.cur",
        "link.cur",
    ]
    scheme_files = [
        "normal.cur",
        "help.cur",
        "working.ani",
        "busy.ani",
        "precision.cur",
        "text.cur",
        "handwriting.cur",
        "unavailable.cur",
        "resize-v.cur",
        "resize-h.cur",
        "resize-d1.cur",
        "resize-d2.cur",
        "move.cur",
        "alternate.cur",
        "link.cur",
    ]
    copy_lines = "\r\n".join(files)
    disk_lines = "\r\n".join(f"{name}=1" for name in files)
    scheme = ",".join(
        rf"%10%\Cursors\Crow-Talon\{name}" for name in scheme_files
    )
    return (
        r"""; Crow Talon v0.2 Windows cursor scheme
; Right-click this file and choose Install. Administrative rights may be
; required because the INF convention stores files under %SystemRoot%\Cursors.
[Version]
Signature="$CHICAGO$"
Class=Mouse

[DefaultInstall]
CopyFiles=CrowTalon.CopyFiles
AddReg=CrowTalon.AddReg

[DefaultInstall.NT]
CopyFiles=CrowTalon.CopyFiles
AddReg=CrowTalon.AddReg

[DestinationDirs]
CrowTalon.CopyFiles=10,"Cursors\Crow-Talon"

[SourceDisksNames]
1="Crow Talon v0.2 Cursor Scheme",,,

[SourceDisksFiles]
"""
        + disk_lines
        + "\r\n\r\n[CrowTalon.CopyFiles]\r\n"
        + copy_lines
        + "\r\n\r\n[CrowTalon.AddReg]\r\n"
        + f'HKCU,"Control Panel\\Cursors\\Schemes","Crow Talon",0x00000000,"{scheme}"\r\n'
    )


def cursor_readme() -> str:
    return f"""# Crow Talon v{PACKAGE_VERSION}

Crow Talon is the original pixel-art Windows pointer family for the Crow Theme.
It uses black and gunmetal silhouettes, cyan edge light, ultraviolet signal
details, and the canonical triangular three-eye motif. The artwork is built on
a 32-pixel grid and scaled without smoothing to 32, 48, 64, and 96 pixels.

## Install for the current Windows user

1. Extract the **entire** `{PACKAGE_PATH.name}` archive.
2. Open PowerShell in the extracted `{PACKAGE_STEM}` folder.
3. Run `./install.ps1` to register the scheme.
4. Select **Crow Talon** under **Mouse Properties > Pointers**.

To register and activate it in one step, run `./install.ps1 -Activate`.
To remove the scheme, run `./uninstall.ps1`.

Do not download or run `install.ps1` by itself: it requires the sibling
`windows` payload folder included in the ZIP.

`Crow-Talon.inf` is also provided for the classic system-wide Windows install
flow. That route can require administrator approval.

## Included roles

Arrow, Help, AppStarting, Wait, Crosshair, IBeam, NWPen, No, SizeNS, SizeWE,
SizeNWSE, SizeNESW, SizeAll, UpArrow, and Hand. Working and Busy include both
animated ANI files and static CUR fallbacks.

## Integrity and source

- `manifest.json` records every role, embedded size, hotspot, and SHA-256.
- `package-files.sha256` records the archive payload checksums.
- `{PACKAGE_HASH_PATH.name}` beside the ZIP validates the archive itself.
- `scripts/build_cursors.py` is the deterministic procedural source.

The approved biomechanical three-eyed Crow was used as the visual identity
reference only; no third-party cursor, system pointer, font glyph, or reference
raster is embedded in the cursor artwork. The visible artwork is calibrated
against the footprint of the standard Windows pointer rather than stretched to
fill every accessibility canvas.
"""


def write_text_outputs() -> None:
    (CURSOR_ROOT / "install.ps1").write_text(install_ps1(), encoding="utf-8", newline="\n")
    (CURSOR_ROOT / "uninstall.ps1").write_text(
        uninstall_ps1(), encoding="utf-8", newline="\n"
    )
    (CURSOR_ROOT / "Crow-Talon.inf").write_text(
        cursor_inf(), encoding="utf-8", newline=""
    )
    README_PATH.write_text(cursor_readme(), encoding="utf-8", newline="\n")


def package_entries() -> list[tuple[Path, str]]:
    entries = [
        (CURSOR_ROOT / "install.ps1", "install.ps1"),
        (CURSOR_ROOT / "uninstall.ps1", "uninstall.ps1"),
        (CURSOR_ROOT / "Crow-Talon.inf", "Crow-Talon.inf"),
        (CURSOR_ROOT / "README.md", "README.md"),
        (CURSOR_ROOT / "manifest.json", "manifest.json"),
        (PREVIEW_PATH, "preview.png"),
        (REPO_ROOT / "scripts" / "build_cursors.py", "scripts/build_cursors.py"),
        (REPO_ROOT / "LICENSE.md", "LICENSE.md"),
    ]
    entries.extend(
        (path, f"src/{path.name}") for path in sorted(SOURCE_DIR.glob("*.png"))
    )
    entries.extend(
        (path, f"windows/{path.name}")
        for path in sorted(WINDOWS_DIR.glob("*"))
        if path.is_file()
    )
    return sorted(entries, key=lambda entry: entry[1].casefold())


def write_distribution_package() -> dict[str, object]:
    entries = package_entries()
    missing = [str(path) for path, _ in entries if not path.is_file()]
    if missing:
        raise ValueError(f"Cannot package Crow Talon; missing files: {missing}")

    content_hashes = "".join(
        f"{sha256(path)}  {archive_name}\n" for path, archive_name in entries
    )
    PACKAGE_CONTENT_HASHES_PATH.write_text(
        content_hashes, encoding="utf-8", newline="\n"
    )
    entries.append((PACKAGE_CONTENT_HASHES_PATH, "package-files.sha256"))
    entries.sort(key=lambda entry: entry[1].casefold())

    DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    temporary_path = PACKAGE_PATH.with_suffix(".tmp")
    if temporary_path.exists():
        temporary_path.unlink()
    try:
        with zipfile.ZipFile(
            temporary_path,
            "w",
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=9,
        ) as archive:
            for path, archive_name in entries:
                member = zipfile.ZipInfo(
                    f"{PACKAGE_STEM}/{archive_name}",
                    date_time=(2026, 1, 1, 0, 0, 0),
                )
                member.compress_type = zipfile.ZIP_DEFLATED
                member.external_attr = 0o100644 << 16
                member.create_system = 3
                archive.writestr(member, path.read_bytes())
        temporary_path.replace(PACKAGE_PATH)
    finally:
        if temporary_path.exists():
            temporary_path.unlink()

    with zipfile.ZipFile(PACKAGE_PATH, "r") as archive:
        corrupt = archive.testzip()
        if corrupt:
            raise ValueError(f"{PACKAGE_PATH.name}: corrupt member {corrupt}")
        expected_names = {
            f"{PACKAGE_STEM}/{archive_name}" for _, archive_name in entries
        }
        actual_names = set(archive.namelist())
        if actual_names != expected_names:
            raise ValueError(f"{PACKAGE_PATH.name}: archive member mismatch")

    archive_hash = sha256(PACKAGE_PATH)
    PACKAGE_HASH_PATH.write_text(
        f"{archive_hash}  {PACKAGE_PATH.name}\n",
        encoding="utf-8",
        newline="\n",
    )
    for legacy_path in LEGACY_LOCAL_PACKAGES:
        if legacy_path.exists():
            if legacy_path.parent.resolve() != CURSOR_ROOT.resolve():
                raise ValueError(f"Refusing to remove unsafe legacy package: {legacy_path}")
            legacy_path.unlink()
    return {
        "archive": PACKAGE_PATH.name,
        "sha256_file": PACKAGE_HASH_PATH.name,
        "sha256": archive_hash,
        "members": len(entries),
        "bytes": PACKAGE_PATH.stat().st_size,
        "root": PACKAGE_STEM,
    }


def build() -> None:
    SOURCE_DIR.mkdir(parents=True, exist_ok=True)
    WINDOWS_DIR.mkdir(parents=True, exist_ok=True)

    manifest_roles: list[dict[str, object]] = []
    source_fingerprints: set[str] = set()
    validation: dict[str, object] = {
        "cur_structure": "passed",
        "ani_structure": "passed",
        "windows_load_cursor_from_file": "passed" if os.name == "nt" else "not-run",
        "pixel_grid_and_palette": "passed",
        "opaque_hotspots": "passed",
        "role_silhouettes_unique": "passed",
        "warm_colours": "none",
    }

    for spec in SPECS:
        source_path = SOURCE_DIR / f"{spec.role}.png"
        pixel_source = render(spec, LOGICAL_SIZE, 0)
        pixel_meta = validate_pixel_source(spec, pixel_source)
        render(spec, 256, 0).save(source_path, "PNG", optimize=True)
        source_fingerprint = sha256(source_path)
        if source_fingerprint in source_fingerprints:
            raise ValueError(f"{spec.role}: duplicates another role silhouette")
        source_fingerprints.add(source_fingerprint)

        static_path = WINDOWS_DIR / f"{spec.role}.cur"
        static_path.write_bytes(build_cur_bytes(spec, 0))
        entries = parse_cur(static_path.read_bytes(), label=static_path.name)
        for entry in entries:
            expected = hotspot_for_size(spec, int(entry["size"]))
            actual = int(entry["hotspot_x"]), int(entry["hotspot_y"])
            if actual != expected:
                raise ValueError(
                    f"{static_path.name}: hotspot {actual} does not match {expected}"
                )
        load_cursor_from_file(static_path)

        role_record: dict[str, object] = {
            "role": spec.role,
            "windows_registry_name": spec.registry_name,
            "visible_art_scale": spec.visible_scale,
            "source_png": f"src/{spec.role}.png",
            "static_cursor": f"windows/{spec.role}.cur",
            "pixel_source": pixel_meta,
            "embedded_images": entries,
            "sha256": {
                f"src/{spec.role}.png": source_fingerprint,
                f"windows/{spec.role}.cur": sha256(static_path),
            },
        }
        if spec.animated:
            frame_hashes = {
                hashlib.sha256(build_cur_bytes(spec, frame)).hexdigest()
                for frame in range(ANI_FRAMES)
            }
            if len(frame_hashes) != ANI_FRAMES:
                raise ValueError(
                    f"{spec.role}: animation has only {len(frame_hashes)} unique frames"
                )
            ani_path = WINDOWS_DIR / f"{spec.role}.ani"
            ani_path.write_bytes(build_ani_bytes(spec))
            ani_meta = validate_ani(ani_path.read_bytes(), label=ani_path.name)
            ani_meta["unique_frames"] = len(frame_hashes)
            load_cursor_from_file(ani_path)
            role_record["animated_cursor"] = f"windows/{spec.role}.ani"
            role_record["animation"] = ani_meta
            role_record["sha256"][f"windows/{spec.role}.ani"] = sha256(ani_path)  # type: ignore[index]
        manifest_roles.append(role_record)

    write_preview(SPECS)
    write_text_outputs()

    manifest = {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "name": "Crow Talon",
        "version": PACKAGE_VERSION,
        "description": "Compact pixel-art cybernetic crow-claw Windows cursor family for the Crow Theme.",
        "authorship": {
            "method": "Drawn from original 32-pixel geometric primitives in scripts/build_cursors.py",
            "third_party_art": False,
            "system_cursor_assets_embedded": False,
            "identity_reference": {
                "name": "Approved full biomechanical three-eyed Crow mascot",
                "source_filename": "crow-mascot-v3.png",
                "usage": "Visual identity reference only; raster not embedded",
            },
        },
        "design": {
            "geometry": "hard-edged 32-pixel master scaled with nearest-neighbour sampling",
            "primary_pointer": "three hooked cybernetic crow talons on an articulated bird-foot chassis",
            "default_visible_art_scale": VISIBLE_ART_SCALE,
            "scale_calibration": "per-role visible footprints reduced inside each resource to match equivalent standard Windows cursors",
            "fill": ["black", "night", "gunmetal"],
            "edge": "signal cyan",
            "identity_signal": "ultraviolet triangular three-eye motif where legible",
            "warm_colours": False,
            "alpha": "1-bit",
        },
        "windows_scheme_order": [spec.registry_name for spec in SPECS],
        "embedded_sizes": list(SIZES),
        "animation": {
            "roles": ["working", "busy"],
            "frames": ANI_FRAMES,
            "jiffies_per_frame": ANI_JIFFIES,
            "static_fallbacks": ["windows/working.cur", "windows/busy.cur"],
        },
        "installers": {
            "recommended_per_user": "install.ps1",
            "uninstall": "uninstall.ps1",
            "classic_inf": "Crow-Talon.inf",
            "installed_during_build": False,
        },
        "distribution": {
            "archive": f"downloads/{PACKAGE_PATH.name}",
            "archive_sha256": f"downloads/{PACKAGE_HASH_PATH.name}",
            "payload_sha256": "cursors/package-files.sha256",
            "extract_before_install": True,
        },
        "preview": {
            "path": "preview.png",
            "width": PREVIEW_WIDTH,
            "height": PREVIEW_HEIGHT,
            "sha256": sha256(PREVIEW_PATH),
        },
        "roles": manifest_roles,
        "validation": validation,
    }
    manifest_path = CURSOR_ROOT / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n"
    )
    package_meta = write_distribution_package()

    print(
        f"Built {len(SPECS)} static CUR files, 2 ANI files, "
        f"{len(SPECS)} source PNGs, {PREVIEW_PATH.name}, and "
        f"{package_meta['archive']} ({package_meta['members']} members)."
    )
    print(
        "Pixel palette, hotspots, CUR/ANI structure, archive integrity, and "
        "LoadCursorFromFileW validation passed."
    )


if __name__ == "__main__":
    try:
        build()
    except Exception as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise
